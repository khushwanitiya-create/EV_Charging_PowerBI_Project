# DAX Measures and Calculated Tables

## Date table (Modeling > New table)
```DAX
DimDate =
ADDCOLUMNS(
    CALENDAR(DATE(2025,10,1), DATE(2026,9,30)),
    "Year", YEAR([Date]),
    "MonthNo", MONTH([Date]),
    "Month", FORMAT([Date], "MMM"),
    "MonthYear", FORMAT([Date], "MMM YY"),
    "Weekday", FORMAT([Date], "ddd"),
    "IsWeekend", IF(WEEKDAY([Date], 2) >= 6, "Weekend", "Weekday")
)
```
Sort `Month` by `MonthNo`. Mark `DimDate` as a date table.

## Core KPIs
```DAX
Total Revenue = SUMX(FILTER(sessions, sessions[Status] = "Completed"), sessions[RevenueINR])

Total Energy (kWh) = SUM(sessions[EnergyKWh])

Total Sessions = COUNTROWS(sessions)

Completed Sessions = CALCULATE([Total Sessions], sessions[Status] = "Completed")

Failed Sessions = CALCULATE([Total Sessions], sessions[Status] = "Failed")

Failure Rate % = DIVIDE([Failed Sessions], [Total Sessions], 0)

Avg Revenue per Session = DIVIDE([Total Revenue], [Completed Sessions], 0)

Avg Session Duration (min) = AVERAGE(sessions[DurationMin])

Avg Revenue per kWh = DIVIDE([Total Revenue], [Total Energy (kWh)], 0)
```

## Station productivity
```DAX
Active Stations = DISTINCTCOUNT(sessions[StationID])

Total Chargers = SUM(stations[Chargers])

Revenue per Station = DIVIDE([Total Revenue], [Active Stations], 0)

Sessions per Charger per Day =
DIVIDE([Total Sessions], [Total Chargers] * DISTINCTCOUNT(DimDate[Date]), 0)
```

## Time intelligence
```DAX
Revenue LM = CALCULATE([Total Revenue], DATEADD(DimDate[Date], -1, MONTH))

Revenue MoM % = DIVIDE([Total Revenue] - [Revenue LM], [Revenue LM], 0)

Revenue YTD = TOTALYTD([Total Revenue], DimDate[Date])

Revenue 3M Rolling Avg =
AVERAGEX(DATESINPERIOD(DimDate[Date], MAX(DimDate[Date]), -3, MONTH), [Total Revenue])
```

## Ranking and insight helpers
```DAX
City Rank = RANKX(ALL(stations[City]), [Total Revenue], , DESC)

Peak Hour Sessions = MAXX(VALUES(sessions[StartHour]), [Total Sessions])

Weekend Share % =
DIVIDE(
    CALCULATE([Total Sessions], DimDate[IsWeekend] = "Weekend"),
    [Total Sessions], 0)

Failure Flag =
IF([Failure Rate %] > 0.05, "⚠ High", "OK")
```

## Calculated columns
```DAX
-- in stations
Station Age = 2026 - stations[InstallYear]

-- in sessions
Time Band =
SWITCH(TRUE(),
    sessions[StartHour] < 6,  "Night",
    sessions[StartHour] < 12, "Morning",
    sessions[StartHour] < 17, "Afternoon",
    sessions[StartHour] < 22, "Evening Peak",
    "Late Night")
```
