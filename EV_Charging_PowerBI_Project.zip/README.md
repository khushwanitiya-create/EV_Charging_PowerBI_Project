# EV Charging Network Analytics (Power BI)

An individual Power BI project analysing the performance, demand patterns and reliability of an electric vehicle charging network across 10 Indian cities.

## Problem statement
Charging operators need to know where revenue comes from, when demand peaks, and which operators and stations have reliability problems. This dashboard answers those questions for 200 stations over 12 months (Oct 2025 - Sep 2026).

## Dataset
Synthetic data generated with `gen_data.py` (seeded, reproducible), modelled on realistic charging behaviour. It is not real operator data.

| File | Rows | Description |
|---|---|---|
| `data/stations.csv` | 200 | Station, city, region, location type, operator, chargers, charger type, install year |
| `data/sessions.csv` | 446,236 | Session-level data: date, hour, duration, kWh, revenue (INR), status, vehicle type |

## Data model
Star schema: `DimDate` and `stations` each join one-to-many to `sessions`.

## Key insights
- Total revenue is about INR 20.4 crore from 9.0 million kWh delivered, with a failure rate of 4.0%.
- Ultra Fast chargers earn about 63% of revenue, and AC Slow chargers under 3%.
- Ahmedabad, Pune and Bengaluru lead the cities; Chennai, Jaipur and Delhi trail.
- Highway locations earn the most, while Residential locations earn the least.
- Demand peaks at 5-8 PM, with a smaller morning peak at 8 AM.
- ChargeZone has a 6.1% failure rate against about 3.4% for the other operators.
- Monthly revenue grew from about INR 1.44 crore (Oct 2025) to about INR 1.95 crore (Sep 2026).

## Recommendations
1. Add Ultra Fast chargers in high-demand cities and on highways.
2. Review ChargeZone uptime and maintenance contracts.
3. Use off-peak pricing to move load away from the 5-8 PM peak.
4. Reduce residential AC slow-charger investment in favour of workplace and parking sites.

## Files
- `EV_Charging_Analytics.pbix` - the Power BI report
- `dax_measures.md` - all DAX used
- `BUILD_GUIDE.md` - how the report was built
- `gen_data.py` - dataset generator
- `EV_Charging_Analytics_Presentation.pptx` - project presentation

## Tools
Power BI Desktop, Power Query, DAX, Python (data generation).

## Author
Your Name - Individual Project, submitted 13 Oct 2026
