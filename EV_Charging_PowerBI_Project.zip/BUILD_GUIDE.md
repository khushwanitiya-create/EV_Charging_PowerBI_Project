# Power BI Build Guide (about 30-40 minutes)

## 1. Load data
1. Open Power BI Desktop > **Get Data > Text/CSV**.
2. Load `data/stations.csv` and `data/sessions.csv`, then click **Transform Data**.

## 2. Power Query cleaning
- `sessions`: set `Date` to Date, `StartHour`/`DurationMin` to Whole Number, `EnergyKWh`/`RevenueINR` to Decimal.
- Remove duplicates on `SessionID`.
- Add a custom column `RevenueINR` null check: Replace errors with 0.
- Both tables: Trim and Clean text columns. Rename query names to `sessions` and `stations`.
- **Close & Apply**.

## 3. Data model
- Create `DimDate` using the DAX in `dax_measures.md`.
- Relationships (all one-to-many, single direction):
  - `stations[StationID]` 1 → * `sessions[StationID]`
  - `DimDate[Date]` 1 → * `sessions[Date]`
- Add the measures and calculated columns from `dax_measures.md`.

## 4. Report pages

### Page 1: Executive Overview
- KPI cards: Total Revenue, Total Energy (kWh), Total Sessions, Failure Rate %, Avg Revenue per Session
- Line chart: Revenue by MonthYear (add Revenue 3M Rolling Avg)
- Filled map or bar: Revenue by City
- Donut: Revenue by ChargerType
- Slicers: Region, Operator, Year/Month

### Page 2: Station and Location Performance
- Bar: Revenue by LocationType
- Matrix: City x ChargerType with Revenue Per Station (conditional formatting)
- Scatter: Chargers (x) vs Revenue (y), size = Sessions, legend = Operator
- Table: Top 10 stations by revenue (Top N filter)

### Page 3: Demand Patterns
- Column chart: Sessions by StartHour (highlight 17-20)
- Heatmap matrix: Weekday (rows) x Time Band (columns), values = Sessions
- Bar: Sessions by VehicleType
- Card: Weekend Share %

### Page 4: Reliability and Operators
- Bar: Failure Rate % by Operator (red if > 5%, use Failure Flag)
- Line: Failure Rate % by month
- Table: Operator, Sessions, Failed Sessions, Failure Rate %, Revenue

### Page 5 (optional): Drill-through
- Drill-through page by `StationID` showing its monthly revenue and failure rate.

## 5. Finishing
- Apply a consistent theme (View > Themes), add titles and a navigation bar with page buttons.
- Save as `EV_Charging_Analytics.pbix` and export screenshots of each page to `screenshots/`.

## 6. Push to GitHub
```bash
git init
git add .
git commit -m "EV charging analytics Power BI project"
git branch -M main
git remote add origin https://github.com/<your-username>/ev-charging-powerbi.git
git push -u origin main
```
Note: `data/sessions.csv` is about 24 MB, which is under GitHub's 100 MB limit.
