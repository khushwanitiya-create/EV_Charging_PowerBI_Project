import random, csv, datetime as dt
random.seed(2026)
cities = {"Delhi":"North","Mumbai":"West","Bengaluru":"South","Hyderabad":"South","Chennai":"South","Pune":"West","Kolkata":"East","Ahmedabad":"West","Jaipur":"North","Lucknow":"North"}
ctype = ["Highway","Mall","Office","Residential","Public Parking"]
op = ["Tata Power","Statiq","ChargeZone","Ather Grid","Jio-bp Pulse"]
# stations
stations=[]
for i in range(1,201):
    c=random.choice(list(cities))
    stations.append(dict(StationID=f"S{i:03d}",City=c,Region=cities[c],LocationType=random.choice(ctype),Operator=random.choice(op),
        Chargers=random.choice([2,4,6,8]),ChargerType=random.choice(["AC Slow","DC Fast","DC Fast","Ultra Fast"]),InstallYear=random.choice([2021,2022,2023,2024,2025])))
with open("data/stations.csv","w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=stations[0].keys());w.writeheader();w.writerows(stations)
rate={"AC Slow":14,"DC Fast":20,"Ultra Fast":24}
kw={"AC Slow":7,"DC Fast":50,"Ultra Fast":120}
loc_boost={"Highway":1.3,"Mall":1.2,"Office":1.0,"Residential":0.8,"Public Parking":0.9}
rows=[];sid=1
start=dt.date(2025,10,1)
for d in range(365):
    day=start+dt.timedelta(days=d)
    for s in stations:
        n=int(random.gauss(5,2)*loc_boost[s["LocationType"]]*(1+d/900)*(1.25 if day.weekday()>=5 else 1))
        for _ in range(max(n,0)):
            hr=random.choices(range(24),weights=[1,1,1,1,1,2,4,6,7,6,5,5,6,5,5,5,6,8,9,9,7,5,3,2])[0]
            dur=max(10,int(random.gauss(45 if s["ChargerType"]=="AC Slow" else 30,12)))
            kwh=round(min(kw[s["ChargerType"]]*dur/60*random.uniform(.5,.85),80),1)
            rev=round(kwh*rate[s["ChargerType"]]*random.uniform(.95,1.1),1)
            fail=random.random()<(0.06 if s["Operator"]=="ChargeZone" else 0.035)
            rows.append([f"T{sid:07d}",s["StationID"],day.isoformat(),hr,dur,0 if fail else kwh,0 if fail else rev,"Failed" if fail else "Completed",random.choice(["2W","3W","4W","4W","4W","Bus"])]);sid+=1
with open("data/sessions.csv","w",newline="") as f:
    w=csv.writer(f);w.writerow(["SessionID","StationID","Date","StartHour","DurationMin","EnergyKWh","RevenueINR","Status","VehicleType"]);w.writerows(rows)
print(len(rows))
